#include <stdio.h>

int main(void) {
    printf("[Your Student ID]\n");
    return 0;
}
